Feature: Settlement Management

Scenario: View Settlements

Given User is logged in

When User opens Settlement Management

Then Settlement table should display