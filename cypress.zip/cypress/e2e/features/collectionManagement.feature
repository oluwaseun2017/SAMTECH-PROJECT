Feature: Collection Management

Scenario: View Collections

Given User is logged in

When User opens Collection Management

Then Collection table should display