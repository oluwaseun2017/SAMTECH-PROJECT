Feature: User Management

Scenario: View User List

Given User is logged in

When User clicks User Management

Then User list should display

And Search textbox should be visible

And Add User button should be visible