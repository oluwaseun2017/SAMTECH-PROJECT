import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../page/loginpage";
import CollectionPage from "../page/CollectionPage";

const login = new LoginPage();
const collection = new CollectionPage();

Given("User is logged in", () => {

    login.visit();
    login.enterEmail("ayanloyesegun+9@gmail.com");
    login.enterPassword("Password@@1");
    login.clickLogin();

});

When("User opens Collection Management", () => {

    collection.openCollection();

});

Then("Collection table should display", () => {

    collection.verifyCollection();

});