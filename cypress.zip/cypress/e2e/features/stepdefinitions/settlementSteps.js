import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../page/loginpage";
import SettlementPage from "../page/SettlementPage";

const login = new LoginPage();
const settlement = new SettlementPage();

Given("User is logged in", () => {

    login.visit();
    login.enterEmail("ayanloyesegun+9@gmail.com");
    login.enterPassword("Password@@1");
    login.clickLogin();

});

When("User opens Settlement Management", () => {

    settlement.openSettlement();

});

Then("Settlement table should display", () => {

    settlement.verifySettlement();

});