import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../page/loginpage";
import MerchantManagementPage from "../page/MerchantManagementPage";

const login = new LoginPage();
const merchant = new MerchantManagementPage();

Given("User is logged in", () => {

    login.visit();
    login.enterEmail("ayanloyesegun+9@gmail.com");
    login.enterPassword("Password@@1");
    login.clickLogin();

});

When("User opens Merchant Management", () => {

    merchant.openMerchant();

});

Then("Merchant list should display", () => {

    merchant.verifyMerchant();

});

Then("Search field should exist", () => {

    cy.get("input").should("exist");

});

Then("Add Merchant button should exist", () => {

    cy.contains("Add Merchant").should("exist");

});