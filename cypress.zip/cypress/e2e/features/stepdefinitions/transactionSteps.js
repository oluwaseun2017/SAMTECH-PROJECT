import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../page/loginpage";
import TransactionPage from "../page/TransactionPage";

const login = new LoginPage();
const transaction = new TransactionPage();

Given("User is logged in", () => {

    login.visit();
    login.enterEmail("ayanloyesegun+9@gmail.com");
    login.enterPassword("Password@@1");
    login.clickLogin();

});

When("User clicks Transaction Management", () => {

    transaction.openTransaction();

});

Then("Transaction page loads", () => {

    transaction.verifyTransaction();

});

Then("Transaction table should display", () => {

    cy.get("table").should("be.visible");

});