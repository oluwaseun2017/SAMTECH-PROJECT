import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import LoginPage from "../../page/loginpage";
import UserManagementPage from "../../page/UserManagementPage";

const login = new LoginPage();
const user = new UserManagementPage();

Given("User is logged in", () => {

    login.visit();
    login.enterEmail("ayanloyesegun+9@gmail.com");
    login.enterPassword("Password@@1");
    login.clickLogin();

});

When("User clicks User Management", () => {

    user.openUsers();

});

Then("User list should display", () => {

    user.verifyUsers();

});

Then("Search textbox should be visible", () => {

    cy.get("input").should("be.visible");

});

Then("Add User button should be visible", () => {

    cy.contains("Add User").should("be.visible");

});