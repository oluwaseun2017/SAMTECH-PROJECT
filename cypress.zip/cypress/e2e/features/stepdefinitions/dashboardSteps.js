import { Given, Then } from "@badeball/cypress-cucumber-preprocessor";
import DashboardPage from "../page/DashboardPage";
import LoginPage from "../page/loginpage";

const login = new LoginPage();
const dashboard = new DashboardPage();

Given("User is logged in", () => {

    login.visit();
    login.enterEmail("ayanloyesegun+9@gmail.com");
    login.enterPassword("Password@@1");
    login.clickLogin();

});

Then("Dashboard should load successfully", () => {

    dashboard.verifyDashboard();

});

Then("Dashboard cards should be visible", () => {

    cy.get("body").should("be.visible");

});

Then("Sidebar should be visible", () => {

    cy.get("aside").should("be.visible");

});