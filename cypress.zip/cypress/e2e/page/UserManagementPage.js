class UserManagement{

open(){

cy.contains('User Management').click()

}

verify(){

cy.url().should('include','users')

cy.get('table').should('be.visible')

cy.get('input').should('be.visible')

}

}

export default UserManagement;