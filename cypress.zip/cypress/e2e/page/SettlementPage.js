class SettlementPage {

    openSettlement() {
        cy.contains("Settlements Mgt.").click();
    }

    verifySettlementPage() {
        cy.url().should("include", "settlement");
    }

    verifySettlementTable() {
        cy.get("table").should("be.visible");
    }

}

export default SettlementPage;