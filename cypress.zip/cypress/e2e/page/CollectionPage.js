class CollectionPage {

    openCollection() {
        cy.contains("Collections Mgt.").click();
    }

    verifyCollectionPage() {
        cy.url().should("include", "collection");
    }

    verifyCollectionTable() {
        cy.get("table").should("be.visible");
    }

}

export default CollectionPage;