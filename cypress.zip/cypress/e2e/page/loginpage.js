class LoginPage {

visit(){
cy.visit('https://admin.proxima.ng/')
}

enterEmail(email){
cy.get('#email').type(email)
}

enterPassword(password){
cy.get('#password').type(password)
}

clickLogin(){
cy.get('button').contains('Login').click()
}

verifyDashboard(){
cy.url().should('include','dashboard')
}

}

export default LoginPage;