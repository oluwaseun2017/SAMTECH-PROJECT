class TransactionPage {

    openTransaction() {
        cy.contains("Transaction Mgt.").click();
    }

    verifyTransactionPage() {
        cy.url().should("include", "transaction");
    }

    verifyTransactionTable() {
        cy.get("table").should("be.visible");
    }

}

export default TransactionPage;