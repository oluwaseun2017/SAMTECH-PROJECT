class MerchantManagementPage {

    openMerchant() {
        cy.contains("Manage Merchants").click();
    }

    verifyMerchantPage() {
        cy.url().should("include", "merchant");
    }

    verifyMerchantTable() {
        cy.get("table").should("be.visible");
    }

}

export default MerchantManagementPage;