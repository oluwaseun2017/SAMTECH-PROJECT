class DashboardPage{

verifyDashboard(){

cy.contains('Dashboard').should('be.visible')

cy.get('aside').should('be.visible')

cy.get('.card').should('have.length.greaterThan',0)

}

}

export default DashboardPage;